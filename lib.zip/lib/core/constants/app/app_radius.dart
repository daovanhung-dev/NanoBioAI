abstract class AppRadius {
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 20;
}
